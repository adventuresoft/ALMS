<?php

namespace App\Http\Controllers;

use App\Models\BasicSettings\Bank;
use App\Models\BasicSettings\BankBranch;
use App\Models\LoanInfo;
use Illuminate\Http\Request;

class LoanInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['loans'] = LoanInfo::with('user.addressInfo', 'user.farmer', 'bank', 'branch')->latest()->paginate(100);
        return view('backend.pages.loan.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['banks'] = Bank::orderBy('en_name', 'asc')->get();
        return view('backend.pages.loan.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {

            if ($request->id) {
                $loan_info =  LoanInfo::find($request->id);
            } else {
                $loan_info = new LoanInfo();
                $loan_info->user_id = $request->user_id;
            }


            $loan_info->financial_year = $request->financial_year;
            $loan_info->bank_id = $request->bank;
            $loan_info->branch_id = $request->branch;
            $loan_info->loan_type = $request->loan_type;
            $loan_info->amount = $request->loan_amount;

            $loan_info->interest_rate = $request->interest_rate;
            $loan_info->total_payable = $request->total_payable;
            $loan_info->distribution_date = $request->distribution_date;
            $loan_info->ontime_payable_date = $request->ontime_payable_date;
            $loan_info->last_payable_date = $request->last_payable_date;

            $loan_info->status = $request->status;

            $loan_info->guarantor_name = $request->guarantor_name;
            $loan_info->guarantor_father_name = $request->guarantor_father_name;
            $loan_info->guarantor_mother_name = $request->guarantor_mother_name;
            $loan_info->guarantor_profession = $request->guarantor_profession;
            $loan_info->guarantor_dob = $request->guarantor_dob;
            $loan_info->guarantor_nid = $request->guarantor_nid;
            $loan_info->guarantor_address = $request->guarantor_address;
            $loan_info->guarantor_mobile = $request->guarantor_mobile;

            $loan_info->save();

            $data['loan_info'] = $loan_info;
            $data['status'] = true;
            $data['message'] = "Loan generated successfully!";
            return response()->json($data, 200);
        } catch (\Throwable $th) {
            //throw $th;
            $data['status'] = false;
            $data['message'] = "Failed to generate loan";
            $data['error'] = $th->getMessage();
            return response()->json($data, 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LoanInfo  $loanInfo
     * @return \Illuminate\Http\Response
     */
    public function show(LoanInfo $loanInfo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\LoanInfo  $loanInfo
     * @return \Illuminate\Http\Response
     */
    public function edit(LoanInfo $loanInfo)
    {
        $loanInfo->load('branch.bank', 'user.farmer', 'user.addressInfo');
        $data['loan'] = $loanInfo;
        $data['banks'] = Bank::orderBy('en_name', 'asc')->get();
        $data['branches'] = BankBranch::where('bank_id', $loanInfo->bank_id)->get();
        return view('backend.pages.loan.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\LoanInfo  $loanInfo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LoanInfo $loanInfo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\LoanInfo  $loanInfo
     * @return \Illuminate\Http\Response
     */
    public function destroy(LoanInfo $loanInfo)
    {
        try {
            $loanInfo->delete();
            $data['status'] = true;
            $data['message'] = "Deleted Successfully!";
            return response()->json($data, 200);
        } catch (\Throwable $th) {
            //throw $th;
            $data['status'] = false;
            $data['message'] = "Failed to delete";
            $data['errors'] = $th->getMessage();
            return response()->json($data, 500);
        }
    }
}
