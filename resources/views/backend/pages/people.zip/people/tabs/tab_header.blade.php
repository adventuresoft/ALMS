<h3 class="card-title">
   <a href="{{ isset($user->id) ? route('people.edit', $user->id) : '#'}}">           
      <span class="{{$active_tab == 'personal' ? 'text-light' : 'text-dark'}}">Personal</span>        
</a> 
<span class="text-secondary">|</span>   
   <a href="{{ isset($user->id) ? route('people.address', $user->id) : '#'}}">       
       <span class="{{$active_tab == 'address' ? 'text-light' : 'text-dark'}}">Address</span>          
   </a> 
</h3>
